import cupy as cp

def uniform_rand(lower, higher, dimensions):
    data = cp.random.rand(dimensions[0], dimensions[1]) * abs(higher - lower)
    data += lower
    return data